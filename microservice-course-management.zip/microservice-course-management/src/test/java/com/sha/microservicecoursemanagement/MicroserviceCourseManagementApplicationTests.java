package com.sha.microservicecoursemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceCourseManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
